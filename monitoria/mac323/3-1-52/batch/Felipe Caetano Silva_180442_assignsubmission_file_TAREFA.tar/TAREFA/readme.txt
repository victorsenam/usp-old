Compilar com o comando: 
javac-algs4 WordFrequencies.java

Executar com o comando: 
java-algs4 WordFrequencies

Não estou atrasado!!! A data de entrega foi adiada para domingo, segundo Yoshiharu! 
;D
