/********************
 *  Nome: Matheus de Mello Santos Oliveira
 *  NUSP: 8642821
 *  *****************/



public class Word {
    String w;
    int f;
    public String toString() {
        return (w + " " + f);
    }
}

